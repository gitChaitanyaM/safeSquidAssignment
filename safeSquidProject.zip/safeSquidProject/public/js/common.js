//function for Active Navigation Link in Navigation Bar -- All Section
function activeNavLink(elementId){
    let activeLink = "";
    let sAllLinks= document.querySelectorAll(elementId);
    sAllLinks.forEach(function(eachElement){
        activeLink = eachElement.classList.add("active");
    });
    return activeLink;
}

//here i made common function for validation of input fields -- Contact Section
function validInputFeilds(elementId, format, validClass, alertClass) {
    if (elementId.value.trim() != "" && elementId.value.match(format)) {
        elementId.parentElement.classList.remove(alertClass);
        elementId.classList.add(validClass);
    }
    else {
        elementId.parentElement.classList.add(alertClass);
        elementId.classList.remove(validClass);
        count++;
    }
}

//function for displaying details from form into modal -- Contact Section
function displaydetails(elementId, modalelementId) {
    document.querySelector(modalelementId).innerHTML = document.querySelector(elementId).value;
}

//function for removing validClass from form when form is reset -- Contact Section
function removeValidateClass(elementId) {
    document.querySelector(elementId).classList.remove("validclass");
}